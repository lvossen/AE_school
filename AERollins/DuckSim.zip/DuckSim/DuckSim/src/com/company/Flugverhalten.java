package com.company;

public interface Flugverhalten {

  void fliegen();
}
