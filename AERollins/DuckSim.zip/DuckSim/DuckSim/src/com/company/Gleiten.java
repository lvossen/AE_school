package com.company;

public class Gleiten implements Flugverhalten{
  @Override
  public void fliegen() {
    System.out.println("gleiten");
  }
}
