package observer;

public interface Beobachter {

	public void aktualisiere();
}
