package com.company;

public class Gleitente extends Ente {
  Gleitente(Quakverhalten qv, Flugverhalten fV){
    super(qv, fV);
  }

}
