package polymorphie;

public abstract class Stift {

	String schreibfarbe;

	public abstract void gebeSchreibfarbeAus();

}
