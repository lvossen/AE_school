package com.company;

public class Quacken implements Quakverhalten {
  @Override
  public void quaken() {
    System.out.println("quak");
  }
}
