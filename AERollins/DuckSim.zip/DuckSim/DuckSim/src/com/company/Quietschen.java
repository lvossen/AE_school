package com.company;

public class Quietschen implements Quakverhalten {
  @Override
  public void quaken() {
    System.out.println("quietsch");
  }
}
