package com.company;

public class Fliegen implements Flugverhalten{
  @Override
  public void fliegen() {
    System.out.println("fliegen");
  }
}
