package com.company;

public interface Quakverhalten {

  void quaken();
}
